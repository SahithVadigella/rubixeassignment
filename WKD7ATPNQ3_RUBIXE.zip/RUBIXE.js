const registrationForm = document.getElementById('registrationForm');

registrationForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const name = document.getElementById('nameInput').value;
    const email = document.getElementById('emailInput').value;
    const phone = document.getElementById('phoneInput').value;

    // Check if the data is already in Local Storage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const existingUser = users.find(user => user.name === name || user.email === email || user.phone === phone);

    if (existingUser) {
        alert('Name, email, or phone already taken');
        return;
    }

    // Save the new user in Local Storage
    const newUser = {
        name,
        email,
        phone
    };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    alert('User registered successfully!');
    registrationForm.reset();
});